<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MotController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function home()
    {
        //
        return view('Controle1/home');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function affichage(Request $request)
    {

        $myMot=$request->input('mot');


        $lenMot = strlen($myMot);

        $reverMot = strrev($myMot);
        
        $MotArray = str_split($myMot);
        $randomMot = '';
        while (!empty($MotArray)) {
            $randomIndex = array_rand($MotArray);
            $randomMot .= $MotArray[$randomIndex];
            unset($MotArray[$randomIndex]);
        }
        if($lenMot==0){
            return('est un vide !');
        }
        return view('Controle1/Affichage', ['mot'=>$myMot , 'lenMot' => $lenMot, 'reverMot' => $reverMot ,'randomMot'=> $randomMot]);

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
